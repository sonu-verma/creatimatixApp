<?php

require_once 'functions/html.php';
require_once 'functions/common.php';