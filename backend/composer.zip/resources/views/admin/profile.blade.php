@extends('layouts.app')

@section('content')
    <h2>👤 Profile</h2>
    <p>Manage your profile here.</p>
@endsection