@extends('layouts.app')

@section('content')
    <h2>⚙️ Settings</h2>
    <p>Configure your settings here.</p>
@endsection