

<?php $__env->startSection('content'); ?>
    <h2>👤 Profile</h2>
    <p>Manage your profile here.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH S:\xampp\htdocs\creatimatix\inhouse\creatimatixApp\backend\resources\views/admin/profile.blade.php ENDPATH**/ ?>