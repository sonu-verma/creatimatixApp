<div class="turfImages">
    <div id="packageImages" role="tabpanel" style="margin:10px;">
        <div class="card-block">
            <div class="card-header p-4 mb-4">
                <div class="row" style="border-style: ridge;padding: 20px;">
                    <div class="col-md-6">
                        <label for="uploadPhoto" class="custom-file">
                            <input type="file" id="uploadPhoto" class="custom-file-input uploadPhoto">
                            <span class="custom-file-control"></span> </label>
                    </div>
                    <div class="col-md-6">
                        <div class="text-center loader-block uploadProgress" style="display: none;">
                            <div class="preloader4">
                                <div class="double-bounce1"></div>
                                <div class="double-bounce2"></div>
                                <span>0%</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <form class="" action="<?php echo e(route('turf.store.images')); ?>" id="frmTurfImages" method="POST">
                 <?php echo csrf_field(); ?>
                <input type="hidden" name="id_turf" id="turfId" class="turfId" value="<?php echo e($model?->id); ?>" />
                <div class="uploadedImages">
                    <?php if($model?->images): ?>
                        <?php echo $__env->make('admin.turfs.includes.image', ['images' => $model?->images], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endif; ?>
                </div>
                <div class="row mt-4">
                
                </div>
            </form>
            <div class="col-md-12 turf-btns">
                        <button type="button" onclick="document.getElementById('nav-sports-tab').click();"
                            class="btn btn-primary pull-right m-b-15 m-l-15"> Next </button>
                        <button type="submit" onclick="document.getElementById('nav-home-tab').click();"
                            class="btn btn-primary pull-right m-b-15 m-l-15">Previous </button>
                        
                    </div>
        </div>
    </div>
</div><?php /**PATH S:\xampp\htdocs\creatimatix\inhouse\creatimatixApp\backend\resources\views/admin/turfs/includes/turf-images.blade.php ENDPATH**/ ?>