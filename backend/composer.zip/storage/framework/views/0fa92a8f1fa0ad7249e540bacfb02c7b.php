 <!--begin::Footer-->
 <footer class="app-footer text-center">
    <!--begin::To the end-->
    
    <!--end::To the end-->
    <!--begin::Copyright-->
    <strong>
      Copyright &copy; 2014-<?php echo e(date('Y')); ?>&nbsp;
      <a href="#" class="text-decoration-none">Creatimatix</a>.
    </strong>
    All rights reserved.
    <!--end::Copyright-->
  </footer>
  <!--end::Footer--><?php /**PATH S:\xampp\htdocs\creatimatix\inhouse\creatimatixApp\backend\resources\views/layouts/admin/footer.blade.php ENDPATH**/ ?>