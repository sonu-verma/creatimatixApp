<div class="sportList">
    <table class="table table-bordered" id="turfListing">
        <thead>
            <tr>
                <th style="width: 10px">#</th>
                <th>Sport Name</th>
                <th>Dimension</th>
                <th>Capacity</th>
                <th>Rate Par Hours</th>
                <th>Status</th>
                <th style="width: 40px">Action</th>
            </tr>
        </thead>
        <tbody>

            <?php if($sports?->isEmpty()): ?>
                <tr>
                    <td colspan="6" class="text-center">No sports found</td>
                </tr>
            <?php endif; ?>
            <?php $__currentLoopData = $sports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="align-middle">
                <td><?php echo e($sport->id); ?></td>
                <td><?php echo e($sport->sportType->name); ?></td>
                <td><?php echo e($sport->dimensions); ?></td>
                <td><?php echo e($sport->capacity); ?></td>
                <td><?php echo e($sport->rate_per_hour); ?></td>
                <td><?php echo e($sport->status == 1 ? 'Available' : 'Not Available'); ?></td>
                <td>
                    <a class="btb btn-sm btn-primary" href="javascript:void(0)" onclick="turf.editSport(<?php echo e($sport->id); ?>, ` <?php echo e(route('turf.edit.sport', ['sport' => $sport->id])); ?>`)">
                        Edit
                    </a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div><?php /**PATH S:\xampp\htdocs\creatimatix\inhouse\creatimatixApp\backend\resources\views/admin/turfs/includes/sportList.blade.php ENDPATH**/ ?>