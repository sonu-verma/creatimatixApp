

<?php $__env->startSection('content'); ?>
<!--begin::Container-->
<div class="container-fluid">
    <!--begin::Row-->
    <div class="row">
      <div class="col-md-12">
        <div class="card mb-4">
          <div class="card-header">
              <div class="card-header-flex">
                  <h3 class="card-title">Turf Lists</h3>
                  <a class="add-turf" href="<?php echo e(route('turf.create')); ?>">Add Turf</a>
              </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <table class="table table-bordered" id="turfListing">
              <thead>
                <tr>
                  <th style="width: 10px">#</th>
                  <th>Turf Name</th>
                  <th>Location</th>
                  <th>Timing</th>
                  <th>Address</th>
                  <th>Is Available</th>
                  <th style="width: 40px">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $turfs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $turf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="align-middle">
                  <td><?php echo e($turf->id); ?></td>
                  <td><?php echo e($turf->name); ?></td>
                  <td><?php echo e($turf->location); ?></td>
                  <td><?php echo e($turf->timing); ?></td>
                  <td><?php echo e($turf->address); ?></td>
                  <td><?php echo e($turf->status == 1 ? 'Available' : 'Not Available'); ?></td>
                  <td><a class="btb btn-sm btn-primary" href="<?php echo e(route("turf.edit", ['id' => $turf->id])); ?>">Edit</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
          <!-- /.card-body -->
          <div class="card-footer clearfix">
            <div class="d-flex justify-end">
              <?php echo $turfs->links('pagination::bootstrap-4'); ?>

            </div>
          </div>
        </div>
      </div>
    </div>
    <!--end::Row-->
  </div>
  <!--end::Container-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', ['title' => "Turfs"], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH S:\xampp\htdocs\creatimatix\inhouse\creatimatixApp\backend\resources\views/admin/turfs/index.blade.php ENDPATH**/ ?>