<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
</head>
<body>

    <nav class="navbar navbar-expand-lg bg-light">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(url('/dashboard')); ?>">Dashboard</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <?php if(auth()->guard()->guest()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a>
                        </li>
                    <?php else: ?>    
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                <?php echo e(Auth::user()->name); ?>

                            </a>
                            <div class="dropdown-menu">
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" 
                                    onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                    Logout
                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>  
 

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php if(auth()->check()): ?>
            <nav class="col-md-3 col-lg-2 d-md-block bg-dark text-white vh-100 p-3">
            
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a href="<?php echo e(url('/dashboard')); ?>" class="nav-link text-white">
                            <i class="bi bi-house"></i> Home
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('/turfs')); ?>" class="nav-link text-white">
                            <i class="bi bi-house"></i> Turfs
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('/profile')); ?>" class="nav-link text-white">
                            <i class="bi bi-person"></i> Profile
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('/settings')); ?>" class="nav-link text-white">
                            <i class="bi bi-gear"></i> Settings
                        </a>
                    </li>
                </ul>
            </nav>
            <?php endif; ?>
            <!-- Content -->
            <main class="col-md-<?php echo e(auth()->check() ? 9 : 12); ?> ms-sm-auto col-lg-<?php echo e(auth()->check() ? 10 : 12); ?> px-md-4 py-4">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH S:\xampp\htdocs\creatimatix\inhouse\creatimatixApp\backend\resources\views/layouts/app.blade.php ENDPATH**/ ?>