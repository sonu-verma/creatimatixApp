

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Add Turf - Basic Information</h2>
    <form action="<?php echo e(route('turfs.storeBasicInfo')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label class="form-label">Name</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Slug</label>
            <input type="text" name="slug" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Location</label>
            <input type="text" name="location" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Rate per Hour</label>
            <input type="number" name="rate_per_hour" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Next: Add Sports</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH S:\xampp\htdocs\creatimatix\inhouse\creatimatixApp\backend\resources\views/admin/turfs/create.blade.php ENDPATH**/ ?>